
package Informacion;

import java.io.IOException;

public class Informacion {
        // Metodo informacion
    public static void informacion() throws IOException {
       		System.out.println("");
		System.out.println("                                 El JavaDabaClub es un complejo de canchas de futbol, padel y basquet, habilitadas no solo para el deporte profesional,");
		System.out.println("");
		System.out.println("                      si no también para el público en general. Nuestras canchas están en optimas condiciones de mantenimiento, siempre preparadas para la acción.");
		System.out.println("");
		System.out.println("                                 En este gran complejo se encuentra un buffet con una gran variedad de opciones, tanto saludables como comidas rápidas.");
		System.out.println("");
                
		System.out.println("                          Por otro lado también se puede visitar nuestra tienda, en la que se encontrará la mejor indumentaria, calzado y artículos de deporte");
		System.out.println("");
		System.out.println("                                                                  originales y con los mayores estándares de calidad!");
		System.out.println("");
		System.out.println("                       JavaDabaClub! Es posible gracias a sus fundadores:  MARITA - JOHANA - CAROLINA - SOFÍA - ARACELI - DAVID - MARCELO - CIRO - AUGUSTO");
		System.out.println("");
		System.out.println("");
		System.out.println("                                                                   Presiona ENTER para volver al Menú Principal");
		System.in.read(); // Espera un ENTER para continuar
		System.out.println("");
    } // Metodo informacion
}
